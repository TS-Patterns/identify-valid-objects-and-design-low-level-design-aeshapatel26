﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern_Computer_Assembly
{
    public interface IComputerBuilder
    {
        void buildCPU();
        void buildMotherBoard();
        void buildScreen();
        void buildMemory();
        Computer getComputer();
    }
}
