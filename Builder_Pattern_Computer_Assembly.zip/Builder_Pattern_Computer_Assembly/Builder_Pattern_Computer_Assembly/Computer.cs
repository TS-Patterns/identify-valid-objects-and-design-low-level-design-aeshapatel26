﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern_Computer_Assembly
{
    public class Computer : IComputerPlan
    {
        double CPUSize;
        double memorySize;
        double motherBoardSize;
        double scrrenWidth;
        double screenHeight;

        public void setCPU(double CPUSize)
        {
            this.CPUSize = CPUSize;
        }

        public void setMemory(double memorySize)
        {
            this.memorySize = memorySize;
        }

        public void setMotherBoard(double motherBoardSize)
        {
            this.motherBoardSize = motherBoardSize;
        }

        public void setScreen(double scrrenWidth, double screenHeight)
        {
            this.scrrenWidth = scrrenWidth;
            this.screenHeight = screenHeight;
        }
    }
}
