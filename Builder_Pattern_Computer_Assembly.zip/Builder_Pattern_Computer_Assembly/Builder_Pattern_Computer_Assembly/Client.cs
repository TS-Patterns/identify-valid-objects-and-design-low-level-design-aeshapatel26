﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern_Computer_Assembly
{
    class Client
    {
        static void Main(string[] args)
        {
            IComputerBuilder computerBuilder = new LaptopBuilder();
            ProductionEngineer productionEngineer = new ProductionEngineer(computerBuilder);

            productionEngineer.AssembleComputer();

            Computer myLaptop = productionEngineer.getComputer();
            Console.WriteLine("Computer Assembled Successfully..");
            Console.Read();
        }
    }
}
