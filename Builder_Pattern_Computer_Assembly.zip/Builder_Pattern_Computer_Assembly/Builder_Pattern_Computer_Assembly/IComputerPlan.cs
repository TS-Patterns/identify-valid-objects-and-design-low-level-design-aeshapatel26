﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern_Computer_Assembly
{
    public interface IComputerPlan
    {
        void setCPU(double CPUSize);
        void setMotherBoard(double motherBoardSize);
        void setScreen(double scrrenWidth, double screenHeight);
        void setMemory(double memorySize);
    }
}
