﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern_Computer_Assembly
{
    public class LaptopBuilder : IComputerBuilder
    {
        private Computer laptopComputer;

        public LaptopBuilder()
        {
            laptopComputer = new Computer();
        }

        public void buildCPU()
        {
            laptopComputer.setCPU(900.00);
        }

        public void buildMemory()
        {
            laptopComputer.setMemory(300.00);
        }

        public void buildMotherBoard()
        {
            laptopComputer.setMotherBoard(940.00);
        }

        public void buildScreen()
        {
            laptopComputer.setScreen(300.00, 200.00);
        }

        public Computer getComputer()
        {
            return laptopComputer;
        }
    }
}
