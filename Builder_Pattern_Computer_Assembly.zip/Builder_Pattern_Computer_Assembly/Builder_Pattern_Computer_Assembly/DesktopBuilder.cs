﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern_Computer_Assembly
{
    public class DesktopBuilder : IComputerBuilder
    {
        private Computer desktopComputer;

        public DesktopBuilder()
        {
            desktopComputer = new Computer();
        }

        public void buildCPU()
        {
            desktopComputer.setCPU(1000.00);
        }

        public void buildMemory()
        {
            desktopComputer.setMemory(200.00);
        }

        public void buildMotherBoard()
        {
            desktopComputer.setMotherBoard(1040.00);
        }

        public void buildScreen()
        {
            desktopComputer.setScreen(400.00, 300.00);
        }

        public Computer getComputer()
        {
            return desktopComputer;
        }
    }
}
