﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern_Computer_Assembly
{
    public class ProductionEngineer
    {
        private IComputerBuilder computerBuilder;

        public ProductionEngineer(IComputerBuilder computerBuilder)
        {
            this.computerBuilder = computerBuilder;
        }

        public Computer getComputer()
        {
            return this.computerBuilder.getComputer();
        }

        public void AssembleComputer()
        {
            this.computerBuilder.buildCPU();
            this.computerBuilder.buildMemory();
            this.computerBuilder.buildMotherBoard();
            this.computerBuilder.buildScreen();
        }
    }
}
