﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern_Computer_Assembly
{
    public class NotebookBuilder : IComputerBuilder
    {
        private Computer notebookComputer;

        public NotebookBuilder()
        {
            notebookComputer = new Computer();
        }

        public void buildCPU()
        {
            notebookComputer.setCPU(800.00);
        }

        public void buildMemory()
        {
            notebookComputer.setMemory(100.00);
        }

        public void buildMotherBoard()
        {
            notebookComputer.setMotherBoard(840.00);
        }

        public void buildScreen()
        {
            notebookComputer.setScreen(200.00, 100.00);
        }

        public Computer getComputer()
        {
            return notebookComputer;
        }
    }
}
