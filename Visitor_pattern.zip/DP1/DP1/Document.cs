﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP1
{
    public class Document
    {
        IList<IDocumentPart> documentParts = new List<IDocumentPart>();

        public void Open()
        {

        }

        public void Save()
        {

        }

        public void Close()
        {

        }

        public void Add(IDocumentPart part)
        {
            documentParts.Add(part);
        }

        public void Convert(IDocumentConverter documentConverter)
        {
            foreach (var documentPart in documentParts)
            {
                
                documentPart.Convert(documentConverter);
            }
        }

    }
}
