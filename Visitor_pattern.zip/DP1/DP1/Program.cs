﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP1
{
    class Program
    {
        static void Main(string[] args)
        {
            Document document = new Document();
            document.Add(new Paragraph());
            document.Add(new HyperLink());
            Console.WriteLine("-----HTML Converter------");
            document.Convert(new HTMLConverter());

            Console.WriteLine("-----PDF Converter------");
            document.Convert(new PDFConverter());
            Console.ReadLine();
        }
    }
}
