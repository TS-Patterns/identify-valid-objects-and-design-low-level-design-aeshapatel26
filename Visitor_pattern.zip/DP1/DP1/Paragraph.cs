﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP1
{
    public class Paragraph : IDocumentPart
    {
        public void Convert(IDocumentConverter documentConverter)
        {
            documentConverter.ConvertParagraph(this);
        }

        public void Paint()
        {
            Console.WriteLine("Paragraph Paint Method");
        }

        public void Save()
        {
            Console.WriteLine("Paragraph Save Method");
        }
    }
}
