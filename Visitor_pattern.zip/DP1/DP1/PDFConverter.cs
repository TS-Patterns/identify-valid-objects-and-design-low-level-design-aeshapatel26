﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP1
{
    public class PDFConverter : IDocumentConverter
    {
        public void ConvertHyperLink(HyperLink hyperLink)
        {
            Console.WriteLine("Converts HyperLink to PDF");
        }

        public void ConvertParagraph(Paragraph paragraph)
        {
            Console.WriteLine("Converts Paragrpah to PDF");
        }
    }
}
