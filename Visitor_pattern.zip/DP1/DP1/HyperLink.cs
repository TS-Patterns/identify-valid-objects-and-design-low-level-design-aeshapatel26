﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP1
{
    public class HyperLink : IDocumentPart
    {
        public void Convert(IDocumentConverter documentConverter)
        {
            documentConverter.ConvertHyperLink(this);
        }

        public void Paint()
        {
            Console.WriteLine("HyperLink Paint Method");
        }

        public void Save()
        {
            Console.WriteLine("HyperLink Save Method");
        }
    }
}
