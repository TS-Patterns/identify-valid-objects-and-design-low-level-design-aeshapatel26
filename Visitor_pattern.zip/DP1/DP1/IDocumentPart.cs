﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP1
{
    public interface IDocumentPart
    {
        void Paint();
        void Save();
        void Convert(IDocumentConverter documentConverter);
    }
}
